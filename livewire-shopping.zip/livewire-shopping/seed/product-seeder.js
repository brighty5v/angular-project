var Product=require('../models/product');

var mongoose=require('mongoose');

mongoose.connect('mongodb://localhost:27017/livewireshopping');
var products=[
    new Product({
        imagePath:'https://5.imimg.com/data5/YY/EN/MY-8155364/fresh-apple-500x500.jpg',
        title:'Apple',
        description:'Good for health',
        price:120
    }),

    new Product({
        imagePath:'http://sunonefruits.com/wp-content/uploads/2019/02/orange-fruit.jpg',
        title:'Orange',
        description:'Good for health',
        price:80
    }),

    new Product({
        imagePath:'https://4.imimg.com/data4/WB/RO/MY-1246545/image2-500x500.jpg',
        title:'Watermelon',
        description:'Good for health',
        price:40
    }),

];
var done=0;
for(var i=0; i<products.length; i++){
    products[i].save(function(err,result){
        done++;
        if(done === products.length){
            exit();
        }
    });
}
function exit(){
    mongoose.disconnect();
}
